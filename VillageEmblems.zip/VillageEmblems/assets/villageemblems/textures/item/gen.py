
from PIL import Image
import os

os.chdir("assets/villageemblems/textures/item")

palette = {
    "black":           [0,     0,      0],
    "dark_blue":       [0,     0,      170],
    "dark_green":      [0,     170,    0],
    "dark_aqua":       [0,     170,    170],
    "dark_red":        [170,   0,      0],
    "dark_purple":     [170,   0,      170],
    "gold":            [255,   170,    0],
    "gray":            [170,   170,    170],
    "dark_gray":       [85,    85,     85],
    "blue":            [85,    85,     255],
    "green":           [85,    255,    85],
    "aqua":            [85,    255,    255],
    "red":             [255,   85,     85],
    "light_purple":    [255,   85,     255],
    "yellow":          [255,   255,    85],
    "white":           [255,   255,    255]
}

def set_color(img: Image.Image, color):
    img = img.copy()

    for x in range(img.width):
        for y in range(img.height):
            pixel = img.getpixel((x, y))
            pixel = (int((pixel[0] * color[0])/256.0), int((pixel[1] * color[1])/256.0), int((pixel[2] * color[2])/256.0), pixel[3])
            img.putpixel((x,y ), pixel)

    return img



def process_file(filename):
    # Save cwd
    cwd = os.getcwd()

    img = Image.open(filename)
    img = img.convert("RGBA")

    foldername = filename.replace(".png", "")
    os.mkdir(foldername)
    os.chdir(foldername)

    for color in palette:
        rgb = palette[color]
        new_img = set_color(img, rgb)

        new_img.save(color + ".png")

    # Restore cwd
    os.chdir(cwd)


def process_folder(folder):
    # Save cwd
    cwd = os.getcwd()

    os.chdir(folder)

    folders = [folder for folder in os.listdir() if os.path.isdir(folder)]

    for file in [file for file in os.listdir() if os.path.isfile(file)]:
        process_file(file)

    for folder in folders:
        process_folder(folder)

    # Restore cwd
    os.chdir(cwd)


for folder in [ "crest", "detail" ]:
    process_folder(folder)

